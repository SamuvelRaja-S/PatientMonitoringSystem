from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(916, 713)
        Dialog.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(180, 20, 511, 71))
        self.label.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("../GUI font/PicsArt_11-21-08.27.20.png"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(140, 140, 231, 51))
        self.label_2.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label_2.setText("")
        self.label_2.setPixmap(QtGui.QPixmap("../GUI font/PicsArt_11-21-08.28.24.png"))
        self.label_2.setScaledContents(True)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(150, 300, 231, 51))
        self.label_3.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label_3.setText("")
        self.label_3.setPixmap(QtGui.QPixmap("../GUI font/PicsArt_11-21-08.29.27.png"))
        self.label_3.setScaledContents(True)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(150, 430, 221, 31))
        self.label_4.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label_4.setText("")
        self.label_4.setPixmap(QtGui.QPixmap("../GUI font/PicsArt_11-21-08.30.13.png"))
        self.label_4.setScaledContents(True)
        self.label_4.setObjectName("label_4")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(320, 560, 171, 51))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_2.setStyleSheet("QPushButton{\n"
"background-color: rgb(255, 255, 255);\n"
"border:2px solid rgb(0,0,0);\n"
"border-radius:20px;\n"
"color:black;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"background-color:rgb(255, 0, 0);\n"
"border:2px solid rgb(255, 0, 0);\n"
"color:white;\n"
"}")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(710, 560, 171, 51))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_3.setStyleSheet("QPushButton{\n"
"background-color: rgb(255, 255, 255);\n"
"border:2px solid rgb(0,0,0);\n"
"border-radius:20px;\n"
"color:black;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"background-color:rgb(255, 0, 0);\n"
"border:2px solid rgb(255, 0, 0);\n"
"color:white;\n"
"}")
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(80, 560, 171, 51))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_4.setStyleSheet("QPushButton{\n"
"background-color: rgb(255, 255, 255);\n"
"border:2px solid rgb(0,0,0);\n"
"border-radius:20px;\n"
"color:black;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"background-color:rgb(255, 0, 0);\n"
"border:2px solid rgb(255, 0, 0);\n"
"color:white;\n"
"}")
        self.pushButton_4.setObjectName("pushButton_4")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(50, 110, 61, 111))
        self.label_6.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.label_6.setText("")
        self.label_6.setPixmap(QtGui.QPixmap("C:/Users/HP/Downloads/pngwing.com (5).png"))
        self.label_6.setScaledContents(True)
        self.label_6.setObjectName("label_6")
        self.label_7 = QtWidgets.QLabel(Dialog)
        self.label_7.setGeometry(QtCore.QRect(30, 280, 91, 71))
        self.label_7.setText("")
        self.label_7.setPixmap(QtGui.QPixmap("C:/Users/HP/Downloads/pngwing.com (6).png"))
        self.label_7.setScaledContents(True)
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(Dialog)
        self.label_8.setGeometry(QtCore.QRect(40, 410, 81, 61))
        self.label_8.setText("")
        self.label_8.setPixmap(QtGui.QPixmap("C:/Users/HP/Downloads/pngwing.com (3).png"))
        self.label_8.setScaledContents(True)
        self.label_8.setObjectName("label_8")
        self.label_10 = QtWidgets.QLabel(Dialog)
        self.label_10.setGeometry(QtCore.QRect(420, 140, 111, 51))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.label_10.setFont(font)
        self.label_10.setStyleSheet("border:2px solid rgb(0,0,0);\n"
"background-color: rgb(255, 255, 255);")
        self.label_10.setText("")
        self.label_10.setObjectName("label_10")
        self.label_11 = QtWidgets.QLabel(Dialog)
        self.label_11.setGeometry(QtCore.QRect(420, 290, 180, 51))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.label_11.setFont(font)
        self.label_11.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"border:2px solid rgb(0,0,0);")
        self.label_11.setText("")
        self.label_11.setObjectName("label_11")
        self.label_12 = QtWidgets.QLabel(Dialog)
        self.label_12.setGeometry(QtCore.QRect(420, 420, 111, 51))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        self.label_12.setFont(font)
        self.label_12.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"border:2px solid rgb(0,0,0);")
        self.label_12.setText("")
        self.label_12.setObjectName("label_12")
        self.pushButton_5 = QtWidgets.QPushButton(Dialog)
        self.pushButton_5.setGeometry(QtCore.QRect(520, 560, 171, 51))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_5.setFont(font)
        self.pushButton_5.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_5.setStyleSheet("QPushButton{\n"
"background-color: rgb(255, 255, 255);\n"
"border:2px solid rgb(0,0,0);\n"
"border-radius:20px;\n"
"color:black;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"background-color:rgb(255, 0, 0);\n"
"border:2px solid rgb(255, 0, 0);\n"
"color:white;\n"
"}")
        self.pushButton_5.setObjectName("pushButton_5")
        self.verticalLayoutWidget = QtWidgets.QWidget(Dialog)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(580, 180, 291, 331))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.pushButton_2.setToolTip(_translate("Dialog", "Speak"))
        self.pushButton_2.setText(_translate("Dialog", "Speak"))
        self.pushButton_3.setToolTip(_translate("Dialog", "Exit"))
        self.pushButton_3.setText(_translate("Dialog", "Exit"))
        self.pushButton_4.setToolTip(_translate("Dialog", "Speak"))
        self.pushButton_4.setText(_translate("Dialog", "Measure"))
        self.pushButton_5.setToolTip(_translate("Dialog", "Speak"))
        self.pushButton_5.setText(_translate("Dialog", "Graph"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
