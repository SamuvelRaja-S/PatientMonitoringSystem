from PyQt5.QtWidgets import QDialog
from PyQt5.QtWidgets import QApplication
from PyQt5 import QtGui
import sys
import pyttsx3
import serial
import time
import pyttsx3
from patientpy import Ui_Dialog
from datetime import date
from datetime import datetime
import mysql.connector
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
mydb=mysql.connector.connect(host="localhost",
                             port="3306",
                             user="root",
                             password="sam@2004@",
                             database="patient"
                             )
a=[]
class mainFile(QDialog):
    def __init__(self):
        super(mainFile,self).__init__()
        print("Setting up GUI")
        self.firstUI = Ui_Dialog()
        self.firstUI.setupUi(self)
        self.firstUI.pushButton_4.clicked.connect(self.measure)
        self.firstUI.pushButton_2.clicked.connect(self.speak)
        self.firstUI.pushButton_3.clicked.connect(self.exit)
        self.firstUI.pushButton_5.clicked.connect(self.graph)
        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.figure)
        self.firstUI.verticalLayout.addWidget(self.canvas)
          # Replace 'COM3' with your Arduino's port
          # Allow time for the connection to establish
    def measure(self):
        ro = 36.8
        te = 98.4
        date1=date.today()
        time1=datetime.now()
        curr = time1.strftime("%H:%M:%S")
        ser = serial.Serial('COM3', 9600)
        ser.write(b'1')  # Send a signal to start the measurement on Arduino
        distance = ser.readline().decode().strip()
        a=distance.split()
        self.firstUI.label_13.setText(a[0])
        self.firstUI.label_10.setText(a[1]+"F")
        self.firstUI.label_12.setText("78")
        self.firstUI.label_11.setText(str(ro)+"C")
        heart = self.firstUI.label_12.text()
        room = self.firstUI.label_11.text()
        temp = self.firstUI.label_10.text()
        mycursor=mydb.cursor()
        mycursor.execute("INSERT INTO pat1(date,time,heart,temperature,room) VALUES(%s,%s,%s,%s,%s)",(date1,curr,heart,temp,room))
        mydb.commit()
        
          # Wait before taking the next measurement
    def speak(self):
        en=pyttsx3.init()
        aq=self.firstUI.label_13.text()
        tem=self.firstUI.label_10.text()
        en.setProperty("rate",100)
        en.say("Your Body temperature is "+tem+"Farenheat "+"Your air quality is "+aq)
        en.runAndWait()
    def exit(self):
        sys.exit()
    def graph(self):
        x_data = [1, 2, 3, 4, 5]
        y_data = [2, 4, 1, 7, 3]
        y1_data = [1,2,5,7,8]
        
        # Plot the data
        self.ax.set_xticks([1,2,3,4,5])
        self.ax.set_yticks([2,4,6,8,10])
        self.ax.plot(x_data, y_data, marker='o', linestyle='-')
        self.ax.plot(x_data, y1_data, marker='o', linestyle='-')

        # Set labels and title
        self.ax.set_xlabel('X-axis')
        self.ax.set_ylabel('Y-axis')
        self.ax.set_title('Line Plot Example')
        self.ax.legend(['sam','sat'])
        # Show the plot
        self.canvas.draw() 

if __name__=='__main__':
    app=QApplication(sys.argv)
    ui=mainFile()
    ui.show()
    sys.exit(app.exec_())
